
---
title: "Working with Ponycopters"
linkTitle: "Working with Ponycopters"
date: 2017-01-05
description: >
  A short lead description about this section page. Text here can also be **bold** or _italic_ and can even be split over multiple paragraphs.
---

{{% pageinfo %}}
This is a placeholder page. Replace it with your own content.
{{% /pageinfo %}}


This is the section landing page.

