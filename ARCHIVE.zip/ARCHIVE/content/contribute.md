---
aliases:
- contribute
author: Matthew Hamilton
date: "2022-03-10"
description: How you can contribute
title: Contribute
---

We welcome approaches from potential funders and collaborators interested in contributing to the development of the project - [contact Matthew Hamilton](https://mph-economist.netlify.app/#contact).

