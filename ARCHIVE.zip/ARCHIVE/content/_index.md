---
author: Matthew Hamilton
description: Website of the ready4 open science framework for modular, replicable and generalisable mental health models.
---
