---
date: "2020-05-15T12:00:00Z"
summary: "An additional 82,000 young Victorians could experience mental health disorders as a result of the COVID-19 pandemic than would have been expected had the pandemic not occurred, new modelling by Orygen has shown..."
categories:
 - REPORTS
 - REPORTS (POLICY)
tags:
 - EPIDEMIOLOGY 
 - MENTAL DISORDERS 
thumbnail: images/springtides_logo.png
title: "Modelling predicts an additional 82,000 young Victorians will experience mental ill-health due to COVID-19"
---

URL: https://www.orygen.org.au/About/News-And-Events/2020/Modelling-predicts-an-additional-82,000-young-Vict

Authors:
 - Orygen

## Summary

An additional 82,000 young Victorians could experience mental health disorders as a result of the COVID-19 pandemic than would have been expected had the pandemic not occurred, new modelling by Orygen has shown.